# Open Weather Map Code Challenge 

Submitted By Matthew Richardson. Thank you for reviewing.

## Setup

Consist of HTML, CSS, and plain JavaScript. Any live server should work on any port. I used Visual Studio Code live-server extension. 