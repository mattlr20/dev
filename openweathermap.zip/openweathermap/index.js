window.onload = function () {
    getForecast();
};

document.getElementById('city').addEventListener("keyup", getForecast);

function getJSON(url, callback) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.responseType = 'json';
    xhr.onload = function () {
        var status = xhr.status;
        if (status === 200) {
            callback(null, xhr.response);
        } else {
            callback(status, xhr.response);
        }
    };
    xhr.send();
};

function getForecast() {
    console.clear();
    var params, city, count, p, currentWeatherURL, forecastURL, forecastday;
    city = document.getElementById('city').value;
    params = {
        'q': city,
        'appid': '8eec3b97e317997c5a2cae1c8ba6c2fb',
        'units': 'imperial'
    };

    p = '?' + Object.keys(params)
        .map((key) => {
            return key + '=' + params[key]
        })
        .join('&');

    currentWeatherURL = 'http://api.openweathermap.org/data/2.5/weather' + p;
    forecastURL = 'http://api.openweathermap.org/data/2.5/forecast' + p;

    getJSON(currentWeatherURL,
        function (err, data) {
            if (err !== null) {
                console.log('Something went wrong: ' + err);
            } else {
                var weather;
                weather = document.getElementsByClassName('current-weather')[0];
                weather.getElementsByClassName('current-temp')[0].innerHTML = data.main.temp;
                weather.getElementsByClassName('curr-icon')[0].src = 'http://openweathermap.org/img/w/' + data.weather[0].icon + '.png';
                weather.getElementsByClassName('humidity')[0].innerHTML = data.main.humidity + '% Humidity';
            }
        });

    getJSON(forecastURL,
        function (err, data) {
            if (err !== null) {
                console.log('Something went wrong: ' + err);
            } else {
                var count, forecast, temp_max, temp_min, lastdate;
                count = 0;
                for (var i = 0; i < data.list.length; i++) {
                    temp_max = data.list[i].main.temp_max;
                    temp_min = data.list[i].main.temp_min;
                    if (data.list[i - 1] != undefined || i == 0) {
                        if ((dateFormat(data.list[i].dt_txt) != lastdate)) {
                            lastdate = dateFormat(data.list[i].dt_txt);
                            forecast = document.getElementsByClassName('day')[count];
                            forecast.getElementsByClassName('date')[0].innerHTML = dateFormat(data.list[i].dt_txt);
                            forecast.getElementsByClassName('fore-icon')[0].src = 'http://openweathermap.org/img/w/' + data.list[i].weather[0].icon + '.png';
                            forecast.getElementsByClassName('temp-max')[0].innerHTML = data.list[i].main.temp_max;
                            forecast.getElementsByClassName('temp-min')[0].innerHTML = data.list[i].main.temp_min;
                            count++;
                        }
                    }
                }

            }
        });
}

function dateFormat(date) {
    var date = new Date(date);
    var day = date.getDate();
    var month = date.getMonth();

    var months = [];
    months[0] = 'Jan';
    months[1] = 'Feb';
    months[2] = 'Mar';
    months[3] = 'Apr';
    months[4] = 'May';
    months[5] = 'Jun';
    months[6] = 'Jul';
    months[7] = 'Aug';
    months[8] = 'Sep';
    months[9] = 'Oct';
    months[10] = 'Nov';
    months[11] = 'Dec';

    date = months[month] + ' ' + day;
    return date;
}