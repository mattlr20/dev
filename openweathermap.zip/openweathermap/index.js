window.onload = function () {
    getForecast();
};

document.getElementById('city').addEventListener("keyup", getForecast);
document.getElementById('close').addEventListener("click", clearValue);

function getJSON(url, callback) {
    //XMLHttpRequest
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.responseType = 'json';
    xhr.onload = function () {
        var status = xhr.status;
        if (status === 200) {
            callback(null, xhr.response);
        } else {
            callback(status, xhr.response);
        }
    };
    xhr.send();
};

function getForecast() {
    var params, city, count, p, currentWeatherURL, forecastURL, forecastday;
    city = document.getElementById('city').value;
    //set params for open weather api
    params = {
        'q': city,
        'appid': '8eec3b97e317997c5a2cae1c8ba6c2fb',
        'units': 'imperial'
    };

    p = '?' + Object.keys(params)
        .map((key) => {
            return key + '=' + params[key]
        })
        .join('&');

    currentWeatherURL = 'http://api.openweathermap.org/data/2.5/weather' + p;
    forecastURL = 'http://api.openweathermap.org/data/2.5/forecast' + p;

    getJSON(currentWeatherURL,
        function (err, data) {
            if (err !== null) {
                console.log('Something went wrong: ' + err);
            } else {
                //assign values to elements in current weather section
                var weather;
                weather = document.getElementsByClassName('current-weather')[0];
                weather.getElementsByClassName('current-temp')[0].innerHTML = Math.round(data.main.temp) + '&deg';
                weather.getElementsByClassName('condition')[0].innerHTML = data.weather[0].description;
                weather.getElementsByClassName('humidity')[0].innerHTML = data.main.humidity + '% Humidity';
            }
        });

    getJSON(forecastURL,
        function (err, data) {
            if (err !== null) {
                console.log('Something went wrong: ' + err);
            } else {
                var count, i, forecast, temp_max, temp_min, nextdate, maxArr, minArr, icon;
                count = 0;
                maxArr = minArr = [];
                var iconArr = [];
                nextdate = dateFormat(data.list[0].dt_txt);
                for (var i = 0; i < data.list.length; i++) {
                    //loop through and create arrays for values with same date then get max
                    maxArr.push(data.list[i].main.temp_max);
                    minArr.push(data.list[i].main.temp_min);
                    //create array of icon codes
                    iconArr.push(data.list[i].weather[0].icon);
                    //get the next date in array
                    if (data.list[i + 1] != undefined) {
                        nextdate = dateFormat(data.list[i + 1].dt_txt);
                    }
                    //whenever array date value changes, set values for forecast day
                    if (dateFormat(data.list[i].dt_txt) != nextdate || i == data.list.length - 1) {
                        //decide which icon to use for forecast day
                        icon = mostCommonValue(iconArr);
                        //assign values to elements
                        forecast = document.getElementsByClassName('day')[count];
                        forecast.getElementsByClassName('date')[0].innerHTML = dateFormat(data.list[i].dt_txt);
                        forecast.getElementsByClassName('fore-icon')[0].src = 'http://openweathermap.org/img/w/' + icon + '.png';
                        forecast.getElementsByClassName('temp-max')[0].innerHTML = Math.round(Math.max(...maxArr));
                        forecast.getElementsByClassName('temp-min')[0].innerHTML = Math.round(Math.min(...minArr));
                        //reset arrays for next forecast day
                        maxArr.length = minArr.length = iconArr.length = 0;
                        count++;
                    }
                }

            }
        });
}

function dateFormat(date) {
    //format date from openweather forecast api
    var date = new Date(date);
    var day = date.getDate();
    var month = date.getMonth();

    var months = [];
    months[0] = 'Jan';
    months[1] = 'Feb';
    months[2] = 'Mar';
    months[3] = 'Apr';
    months[4] = 'May';
    months[5] = 'Jun';
    months[6] = 'Jul';
    months[7] = 'Aug';
    months[8] = 'Sep';
    months[9] = 'Oct';
    months[10] = 'Nov';
    months[11] = 'Dec';

    date = months[month] + ' ' + day;
    return date;
}

function mostCommonValue(arr1) {
    //loop through array to figure out with weather icon used most frequently
    var mf = 1;
    var m = 0;
    var item;
    for (var i = 0; i < arr1.length; i++) {
        for (var j = i; j < arr1.length; j++) {
            if (arr1[i] == arr1[j])
                m++;
            if (mf < m) {
                mf = m;
                item = arr1[i];
            }
        }
        m = 0;
    }
    console.log((item + " ( " + mf + " times ) "));
    return (item);
}

function clearValue() {
    //clear value of search box
    document.getElementById('city').value = '';
}